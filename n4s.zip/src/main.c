/*
** EPITECH PROJECT, 2020
** n4s
** File description:
** main function
*/

#include <stdio.h>
#include <stdlib.h>
#include "stuff.h"

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    start();
    run();
    return 0;
}